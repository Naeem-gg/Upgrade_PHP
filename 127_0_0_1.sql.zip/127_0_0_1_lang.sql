--
-- Database: `lang`
--
CREATE DATABASE IF NOT EXISTS `lang` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lang`;

-- --------------------------------------------------------

--
-- Table structure for table `langs`
--

DROP TABLE IF EXISTS `langs`;
CREATE TABLE `langs` (
  `srno` int(11) NOT NULL,
  `lang_name` varchar(30) NOT NULL,
  `year` int(11) NOT NULL,
  `lang_logo` varchar(60) NOT NULL,
  `lang_desc` text NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `langs`
--

INSERT INTO `langs` (`srno`, `lang_name`, `year`, `lang_logo`, `lang_desc`, `date`) VALUES
(4, 'Typescript', 2012, 'images/Typescript.png', 'TypeScript is a programming language developed and maintained by Microsoft. It is a strict syntactical superset of JavaScript and adds optional static typing to the language. It is designed for the development of large applications and transpiles to JavaScript.', '15:33:01'),
(5, 'Solidity', 2018, 'images/solidity.png', 'Solidity is an object-oriented programming language for implementing smart contracts on various blockchain platforms, most notably, Ethereum. It was developed by Christian Reitwiessner, Alex Beregszaszi, and several former Ethereum core contributors. Programs in Solidity run on Ethereum Virtual Machine', '15:33:48'),
(6, 'JavaScipt', 1994, 'images/javascript.png', 'JavaScript, often abbreviated JS, is a programming language that is one of the core technologies of the World Wide Web, alongside HTML and CSS. As of 2022, 98% of websites use JavaScript on the client side for web page behavior, often incorporating third-party libraries', '15:34:40'),
(7, 'Java', 1993, 'images/java.webp', 'Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.', '15:35:14'),
(8, 'python', 1991, 'images/python.png', 'this is python', '15:11:44'),
(9, 'javascript', 1995, 'images/javascript.png', 'this is pure OOPs based lang', '15:12:06'),
(10, 'solidity', 2018, 'images/solidity.png', 'web 3.0', '15:12:23'),
(11, 'java', 1992, 'images/java.webp', 'yo', '15:12:36'),
(12, 'coffeescript', 1999, 'images/coffeescript.png', 'no this is nothing like coffee', '15:13:51'),
(13, 'CSS', 1996, 'images/css.png', 'this is css', '15:14:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `langs`
--
ALTER TABLE `langs`
  ADD PRIMARY KEY (`srno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `langs`
--
ALTER TABLE `langs`
  MODIFY `srno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
