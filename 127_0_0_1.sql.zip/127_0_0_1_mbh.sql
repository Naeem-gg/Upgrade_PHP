--
-- Database: `mbh`
--
CREATE DATABASE IF NOT EXISTS `mbh` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mbh`;

-- --------------------------------------------------------

--
-- Table structure for table `invitees`
--

DROP TABLE IF EXISTS `invitees`;
CREATE TABLE `invitees` (
  `SrNo` tinyint(3) UNSIGNED NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Mobile` bigint(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invitees`
--

INSERT INTO `invitees` (`SrNo`, `Name`, `Mobile`, `email`, `password`) VALUES
(0, 'Junaid', 911234567890, 'junaid@gmail.com', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invitees`
--
ALTER TABLE `invitees`
  ADD PRIMARY KEY (`SrNo`);
