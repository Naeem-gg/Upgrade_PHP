--
-- Database: `i`
--
CREATE DATABASE IF NOT EXISTS `i` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `i`;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `studentid` tinyint(4) NOT NULL,
  `studentname` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `teacherid` tinyint(4) NOT NULL,
  `teachername` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacherid`, `teachername`) VALUES
(4, 'naeem'),
(5, 'musharraf'),
(6, 'armagan'),
(7, 'shahebaz'),
(8, 'shoeb'),
(9, 'abdullah'),
(13, 'adnan'),
(15, 'prince'),
(18, 'princess'),
(20, 'soldier sir'),
(23, 'iftar sir');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacherid`);
