--
-- Database: `naeemm`
--
CREATE DATABASE IF NOT EXISTS `naeemm` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `naeemm`;
