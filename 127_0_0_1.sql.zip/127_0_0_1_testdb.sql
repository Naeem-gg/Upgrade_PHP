--
-- Database: `testdb`
--
CREATE DATABASE IF NOT EXISTS `testdb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `testdb`;

-- --------------------------------------------------------

--
-- Table structure for table `testdb`
--

DROP TABLE IF EXISTS `testdb`;
CREATE TABLE `testdb` (
  `srno` tinyint(250) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testdb`
--

INSERT INTO `testdb` (`srno`, `name`, `email`, `username`, `password`) VALUES
(1, 'name1', 'emai@gmail.com1', 'username1', 'pass1'),
(2, 'name2', 'emai@gmail.com2', 'username2', 'pass2'),
(3, 'name3', 'emai@gmail.com3', 'username3', 'pass3'),
(4, 'name4', 'emai@gmail.com4', 'username4', 'pass4'),
(5, 'name5', 'emai@gmail.com5', 'username5', 'pass5'),
(6, 'name6', 'emai@gmail.com6', 'username6', 'pass6'),
(7, 'name7', 'emai@gmail.com7', 'username7', 'pass7'),
(8, 'name8', 'emai@gmail.com8', 'username8', 'pass8'),
(9, 'name9', 'emai@gmail.com9', 'username9', 'pass9'),
(10, 'name10', 'emai@gmail.com10', 'username10', 'pass10'),
(11, 'name11', 'emai@gmail.com11', 'username11', 'pass11'),
(12, 'name12', 'emai@gmail.com12', 'username12', 'pass12'),
(13, 'name13', 'emai@gmail.com13', 'username13', 'pass13'),
(14, 'name14', 'emai@gmail.com14', 'username14', 'pass14'),
(15, 'name15', 'emai@gmail.com15', 'username15', 'pass15'),
(16, 'name16', 'emai@gmail.com16', 'username16', 'pass16'),
(17, 'name17', 'emai@gmail.com17', 'username17', 'pass17'),
(18, 'name18', 'emai@gmail.com18', 'username18', 'pass18'),
(19, 'name19', 'emai@gmail.com19', 'username19', 'pass19'),
(20, 'name20', 'emai@gmail.com20', 'username20', 'pass20'),
(21, 'name21', 'emai@gmail.com21', 'username21', 'pass21'),
(22, 'name22', 'emai@gmail.com22', 'username22', 'pass22'),
(23, 'name23', 'emai@gmail.com23', 'username23', 'pass23'),
(24, 'name24', 'emai@gmail.com24', 'username24', 'pass24'),
(25, 'name25', 'emai@gmail.com25', 'username25', 'pass25'),
(26, 'name26', 'emai@gmail.com26', 'username26', 'pass26'),
(27, 'name27', 'emai@gmail.com27', 'username27', 'pass27'),
(28, 'name28', 'emai@gmail.com28', 'username28', 'pass28'),
(29, 'name29', 'emai@gmail.com29', 'username29', 'pass29'),
(30, 'name30', 'emai@gmail.com30', 'username30', 'pass30'),
(31, 'name31', 'emai@gmail.com31', 'username31', 'pass31'),
(32, 'name32', 'emai@gmail.com32', 'username32', 'pass32'),
(33, 'name33', 'emai@gmail.com33', 'username33', 'pass33'),
(34, 'name34', 'emai@gmail.com34', 'username34', 'pass34'),
(35, 'name35', 'emai@gmail.com35', 'username35', 'pass35'),
(36, 'name36', 'emai@gmail.com36', 'username36', 'pass36'),
(37, 'name37', 'emai@gmail.com37', 'username37', 'pass37'),
(38, 'name38', 'emai@gmail.com38', 'username38', 'pass38'),
(39, 'name39', 'emai@gmail.com39', 'username39', 'pass39'),
(40, 'name40', 'emai@gmail.com40', 'username40', 'pass40'),
(41, 'name41', 'emai@gmail.com41', 'username41', 'pass41'),
(42, 'name42', 'emai@gmail.com42', 'username42', 'pass42'),
(43, 'name43', 'emai@gmail.com43', 'username43', 'pass43'),
(44, 'name44', 'emai@gmail.com44', 'username44', 'pass44'),
(45, 'name45', 'emai@gmail.com45', 'username45', 'pass45'),
(46, 'name46', 'emai@gmail.com46', 'username46', 'pass46'),
(47, 'name47', 'emai@gmail.com47', 'username47', 'pass47'),
(48, 'name48', 'emai@gmail.com48', 'username48', 'pass48'),
(49, 'name49', 'emai@gmail.com49', 'username49', 'pass49'),
(50, 'name50', 'emai@gmail.com50', 'username50', 'pass50'),
(1, 'name1', 'emai@gmail.com1', 'username1', 'pass1');
