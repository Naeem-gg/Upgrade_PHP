--
-- Database: `naeem`
--
CREATE DATABASE IF NOT EXISTS `naeem` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `naeem`;

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `teacherid` tinyint(4) NOT NULL,
  `teachername` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacherid`, `teachername`) VALUES
(1, 'naeem');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacherid`);
